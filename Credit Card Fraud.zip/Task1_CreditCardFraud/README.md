Libraries and Techniques Used

- **Pandas** (`pandas`) for data manipulation and analysis.
- **NumPy** (`numpy`) for numerical operations.
- **Scikit-Learn** (`scikit-learn`) for machine learning tools, including RandomForestClassifier, StandardScaler, LabelEncoder, OneHotEncoder, and IncrementalPCA.
- **Imbalanced-Learn** (`imblearn`) for oversampling with SMOTE to address class imbalance.
- **TQDM** (`tqdm`) for displaying progress bars during data processing.


Requirements

- Python 3.x
- Pandas (`pandas`)
- NumPy (`numpy`)
- Scikit-Learn (`scikit-learn`)
- TQDM (`tqdm`)
- **Imbalanced-Learn** (`imblearn`)


